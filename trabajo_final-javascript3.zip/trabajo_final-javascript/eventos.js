// DATA INICIAL
const eventosPorDefecto = [
    { titulo: "MALUMA", descripcion: "CONCIERTO DE MALUMA EN EL ESTADIO", fecha: "2025-08-17", estado: "activo" },
    { titulo: "CHAMPIONS", descripcion: "LA CHAMPPIONS DE FUTBOL", fecha: "2025-12-29", estado: "activo" },
    { titulo: "MUNDIAL", descripcion: "INICIO DEL MUNDIA", fecha: "2026-04-05", estado: "inactivo" },
    { titulo: "TORNEO NACIONAL DE PADEL", descripcion: "COMPETENCIA A NIVEL NACIONAL DE PADEL", fecha: "2025-07-20", estado: "cancelado" },
];

const subsPorDefecto = [
    { nombre: "alexander lainez", correo: "alex@gmail.com.com", fecha: "2025-07-01" }
];

const eventos = JSON.parse(localStorage.getItem("eventos")) || eventosPorDefecto;

// ─────────────────────────────────────────────
// MOSTRAR EVENTOS ACTIVOS EN index.html
if (window.location.pathname.includes("index.html")) {
    const contenedorEventos = document.querySelector("#eventos .grid");
    if (contenedorEventos) {
        contenedorEventos.innerHTML = "";
        eventos
            .filter(e => e.estado === "activo")
            .forEach(ev => {
                contenedorEventos.innerHTML += `
        <div >
        <div >📌​</div>
        <div>
            <h3 >${ev.titulo}</h3>
            <p >${ev.descripcion}</p>
            <div>
            <span>${ev.fecha}</span>
            </div>
        </div>
        </div>`;
            });
    }

}

// ─────────────────────────────────────────────
// MOSTRAR EVENTOS EN inicio.html
if (window.location.pathname.includes("inicio.html")) {
    const tabla = document.querySelector("table tbody");
    const botonAgregar = document.querySelector("button.bg-green-600");

    function renderEventos() {
        tabla.innerHTML = "";
        eventos.forEach((e, i) => {
            tabla.innerHTML += `
        <tr class="border-t">
        <td class="p-4">
            <input type="text" value="${e.titulo}" onchange="actualizarCampo(${i}, 'titulo', this.value)" class="border px-2 py-1 w-full rounded">
        </td>
        <td class="p-4">
            <input type="date" value="${e.fecha}" onchange="actualizarCampo(${i}, 'fecha', this.value)" class="border px-2 py-1 w-full rounded">
        </td>
        <td class="p-4">
            <select onchange="actualizarCampo(${i}, 'estado', this.value)" class="border px-2 py-1 w-full rounded">
            <option value="activo" ${e.estado === "activo" ? "selected" : ""}>Activo</option>
            <option value="inactivo" ${e.estado === "inactivo" ? "selected" : ""}>Inactivo</option>
            <option value="cancelado" ${e.estado === "cancelado" ? "selected" : ""}>Cancelado</option>
            </select>
        </td>
        <td class="p-4 space-x-2">
            <button class="bg-red-600 text-white px-3 py-1 rounded" onclick="eliminarEvento(${i})">Eliminar</button>
        </td>
        </tr>`;
        });
    }

    window.actualizarCampo = function (index, campo, valor) {
        eventos[index][campo] = valor;
        localStorage.setItem("eventos", JSON.stringify(eventos));
        renderEventos(); // actualiza visualmente si cambian opciones
    };

    window.eliminarEvento = function (i) {
        if (confirm("¿Eliminar este evento?")) {
            eventos.splice(i, 1);
            localStorage.setItem("eventos", JSON.stringify(eventos));
            renderEventos();
        }
    };

    botonAgregar.addEventListener("click", () => {
        const titulo = prompt("Título del evento:");
        const descripcion = prompt("Descripción:");
        const fecha = prompt("Fecha (YYYY-MM-DD):");
        const estado = prompt("Estado (activo/inactivo/cancelado):", "activo");

        if (titulo && descripcion && fecha && estado) {
            eventos.push({ titulo, descripcion, fecha, estado });
            localStorage.setItem("eventos", JSON.stringify(eventos));
            renderEventos();
        }
    });

    renderEventos();
}

// ─────────────────────────────────────────────
// MOSTRAR SUSCRIPCIONES EN subscriptions.html
if (window.location.pathname.includes("subscriptions.html") || window.location.pathname.includes("dashboard.html")) {
    const tabla = document.querySelector("table tbody");
    if (tabla) {
        tabla.innerHTML = "";
        suscriptores.forEach(s => {
            tabla.innerHTML += `
        <tr class="border-t">
        <td class="p-4">${s.nombre}</td>
        <td class="p-4">${s.correo}</td>
        <td class="p-4">${s.fecha}</td>
        </tr>`;
        });
    }
}